// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:e_coomerce_fruit/constants.dart';
// import 'package:e_coomerce_fruit/core/helper_functions/app_router.dart';
// import 'package:e_coomerce_fruit/core/services/firebase_auth_services.dart';
// import 'package:e_coomerce_fruit/core/services/shared_preferences_singleton.dart';
// import 'package:e_coomerce_fruit/core/utils/app_images.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/flutter_svg.dart';

// import 'package:go_router/go_router.dart';

// class SplashViewBody extends StatefulWidget {
//   const SplashViewBody({super.key});
//   @override
//   State<SplashViewBody> createState() => _SplashViewBodyState();
// }

// class _SplashViewBodyState extends State<SplashViewBody> {
//    late StreamSubscription<ConnectivityResult> _subscription;
//   bool _hasNavigated = false; // prevent repeated navigation

//   @override
//   void initState() {
//     super.initState();
//     _startNavigationFlow();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.stretch,
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Row(
//           mainAxisAlignment: MainAxisAlignment.end,
//           children: [SvgPicture.asset(Assets.imagesPlanet)],
//         ),
//         SvgPicture.asset(Assets.imagesLogo),
//         SvgPicture.asset(Assets.imagesCirculesSplash, fit: BoxFit.fill),
//       ],
//     );
//   }

// // Network-aware navigation
// void _startNavigationFlow() async {
//     // 3-second splash delay
//     await Future.delayed(const Duration(seconds: 3));

//     // Listen to connectivity changes
//     _subscription = Connectivity().onConnectivityChanged.listen((result) {
//       bool isOnline =
//           result == ConnectivityResult.mobile ||
//           result == ConnectivityResult.wifi ||
//           result == ConnectivityResult.ethernet;

//       if (isOnline) {
//         log('Connected to the internet');

//         // Navigate only once
//         if (!_hasNavigated) {
//           _hasNavigated = true;
//           _navigateBasedOnPrefsAndAuth();
//         }
//       } else {
//         log('No internet connection');
//         if (!_hasNavigated) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//               content: Text(
//                 'No Internet Connection. Please check your network and try again.',
//               ),
//               backgroundColor: Colors.red,
//               duration: Duration(seconds: 3),
//             ),
//           );
//         }
//       }
//     });
//   }
//   void executeNavigation() {
//     bool isOnBoardingViewSeen = Prefs.getBool(kIsOnBoardingViewSeen);
//     Future.delayed(Duration(seconds: 3), () {
//       if (isOnBoardingViewSeen) {
//         var isLoggedIn = FirebaseAuthService().isLoggedIn();
//         // if (isLoggedIn) {
//         //   // GoRouter.of(context).push(AppRouter.kHomeView);
//         // }
//         // else
//         // {
//         //   GoRouter.of(context).push(AppRouter.kSigninView);
//         // }
//       } else {
//         GoRouter.of(context).push(AppRouter.kOnboarding);
//       }
//     });
//   }
// // Show No Internet dialog with Retry
//   void _showNoInternetDialog() {
//     showDialog(
//       context: context,
//       barrierDismissible: false, // force user to choose
//       builder: (context) => AlertDialog(
//         title: const Text('No Internet Connection'),
//         content: const Text(
//           'Please check your network settings and try again.',
//         ),
//         actions: [
//           TextButton(
//             onPressed: () {
//               // Retry button -> re-run network check
//               Navigator.of(context).pop();
//               _startNavigationFlow();
//             },
//             child: const Text('Retry'),
//           ),
//         ],
//       ),
//     );
//   }
// }

import 'dart:async';
import 'dart:developer';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:e_coomerce_fruit/constants.dart';
import 'package:e_coomerce_fruit/core/helper_functions/app_router.dart';
import 'package:e_coomerce_fruit/core/services/firebase_auth_services.dart';
import 'package:e_coomerce_fruit/core/services/shared_preferences_singleton.dart';
import 'package:e_coomerce_fruit/core/utils/app_images.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

class SplashViewBody extends StatefulWidget {
  const SplashViewBody({super.key});
  @override
  State<SplashViewBody> createState() => _SplashViewBodyState();
}

class _SplashViewBodyState extends State<SplashViewBody> {
  // Listener for initial checks only. The global check is in ConnectivityBanner.
  // Note: We need to use 'late' or make it nullable for safety.
  // Given initState sets it, 'late' is typically fine, but checking for null
  // in dispose adds robustness.
  late StreamSubscription<List<ConnectivityResult>> _subscription;

  bool _hasNavigated = false;
  bool _isOnline = false; // Initial assumption is offline until checked
  final Duration _splashDuration = const Duration(seconds: 3);

  @override
  void initState() {
    super.initState();
    _startAppInitialization();
  }

  @override
  void dispose() {
    // Cancel the subscription upon disposal
    if (_subscription != null) {
      _subscription.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // --- Splash Screen UI (Logo and Graphics) ---
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [SvgPicture.asset(Assets.imagesPlanet)],
            ),
            SvgPicture.asset(Assets.imagesLogo),
            SvgPicture.asset(Assets.imagesCirculesSplash, fit: BoxFit.fill),
          ],
        ),

        // --- No Internet Overlay (During Splash Only) ---
        if (!_isOnline)
          Positioned.fill(
            child: Container(
              color: Colors.black54, // Dark overlay
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(24.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.wifi_off, color: Colors.red, size: 48),
                      SizedBox(height: 16),
                      Text(
                        'No Internet Connection',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.red,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Checking connection...',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  bool _isConnected(List<ConnectivityResult> results) {
    return results.contains(ConnectivityResult.mobile) ||
        results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.ethernet);
  }

  void _startAppInitialization() async {
    // 1. Check initial connectivity state
    final initialResults = await Connectivity().checkConnectivity();
    _isOnline = _isConnected(initialResults);
    if (mounted)
      setState(() {}); // Update UI to show/hide the overlay immediately

    // 2. Start the connectivity listener (to handle connection coming back online during splash)
    _subscription = Connectivity().onConnectivityChanged.listen((
      List<ConnectivityResult> results,
    ) {
      if (!mounted) return;

      final newIsOnline = _isConnected(results);

      // Update the local state for the UI (the splash error overlay)
      if (newIsOnline != _isOnline) {
        setState(() {
          _isOnline = newIsOnline;
        });
      }

      // 3. Navigate immediately if connectivity is established and we've waited
      if (newIsOnline && !_hasNavigated) {
        log('Connected to the internet, navigating...');
        _hasNavigated = true;
        _navigateBasedOnPrefsAndAuth();
      }
    });

    // 4. Wait for the minimum splash screen duration
    await Future.delayed(_splashDuration);

    // 5. Final attempt to navigate if online and not navigated by the stream yet.
    if (_isOnline && !_hasNavigated) {
      _hasNavigated = true;
      _navigateBasedOnPrefsAndAuth();
    }
  }

  // void _navigateBasedOnPrefsAndAuth() {
  //   if (!mounted) return;

  //   bool isOnBoardingViewSeen = Prefs.getBool(kIsOnBoardingViewSeen);
  //   final router = GoRouter.of(context);

  //   if (isOnBoardingViewSeen) {
  //     bool isLoggedIn = FirebaseAuthService().isLoggedIn();
  //     if (isLoggedIn) {
  //       router.go(AppRouter.kHomeView); // Navigate to Home
  //     }
  //     {
  //       router.go(AppRouter.kSigninView); // Navigate to Sign In
  //     }
  //   } else {
  //     router.go(AppRouter.kOnboarding); // Navigate to Onboarding
  //   }
  // }

  // --- Navigation logic ---
  void _navigateBasedOnPrefsAndAuth() {
    if (!mounted) return;

    final router = GoRouter.of(context);

    // -----------------------------
    // NOTE: الكود القديم كان يتحقق من SharedPreferences
    // bool isOnBoardingViewSeen = Prefs.getBool(kIsOnBoardingViewSeen);
    // if (isOnBoardingViewSeen) {
    //    // Navigate to Home or SignIn
    // } else {
    //    router.go(AppRouter.kOnboarding);ف
    // }
    // -----------------------------
    // الآن تم تعديل الكود ليذهب دائماً إلى OnboardingView عند كل فتح للتطبيق
    router.go(AppRouter.kOnboarding);
  }
}
