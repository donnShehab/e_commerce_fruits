String getCurrency() {
  return 'USD';
}
